﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NoteObject : MonoBehaviour
{

    public bool canBePressed;
    public bool hit;

    public KeyCode keyToPress;

    public GameObject hitEffect, goodEffect, perfectEffect, missEffect;
    public AudioSource miss;

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(keyToPress)){
            if(canBePressed == true) {
                //Destroy(gameObject);
                gameObject.GetComponent<Renderer>().enabled = false;
                //gameObject.GetComponent<Collider2D>().enabled = false;

                //GameManager.instance.NoteHit();

                hit = false;

                if (Mathf.Abs(transform.position.y) > 0.25){
                    //gameObject.GetComponent<Renderer>().enabled = false;
                    hit = true;
                    gameObject.GetComponent<Collider2D>().enabled = false;
                    Debug.Log("Normal");
                    GameManager.instance.NormalHit();
                    Instantiate(hitEffect, transform.position, hitEffect.transform.rotation);
                }
                else if(Mathf.Abs(transform.position.y) > 0.1){
                    //gameObject.GetComponent<Renderer>().enabled = false;
                    hit = true;
                    gameObject.GetComponent<Collider2D>().enabled = false;
                    Debug.Log("Good");
                    GameManager.instance.GoodHit();
                    Instantiate(goodEffect, transform.position, goodEffect.transform.rotation);
                }
                else{
                    //gameObject.GetComponent<Renderer>().enabled = false;
                    hit = true;
                    gameObject.GetComponent<Collider2D>().enabled = false;
                    Debug.Log("Perfect!");
                    GameManager.instance.PerfectHit();
                    Instantiate(perfectEffect, transform.position, perfectEffect.transform.rotation);
                }
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other){
        if(other.tag == "Activator"){
            canBePressed = true; 
        }
    }

    /*private void OnTriggerExit2D(Collider2D other){
        if(other.tag == "Activator"){
            canBePressed = false;

            if (hit == false)
            {
                GameManager.instance.NoteMissed();
                miss.Play();
                Instantiate(missEffect, transform.position, missEffect.transform.rotation);
            }
        }
    }*/
}
